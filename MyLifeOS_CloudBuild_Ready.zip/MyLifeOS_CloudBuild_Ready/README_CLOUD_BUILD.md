# My Life OS — Cloud Build Ready

This project is prepared for a GitHub Actions cloud build.

## Build
The workflow at `.github/workflows/android.yml` runs on every push to `main` and can also be started manually. It builds `assembleDebug` and uploads the APK as a workflow artifact.

## Phone-only route
1. Create/sign in to a GitHub account.
2. Create a new repository.
3. Upload the contents of this project to the repository (not the ZIP file itself).
4. Open the repository's **Actions** tab.
5. Run **Build My Life OS APK**.
6. When it finishes, open the run and download the `MyLifeOS-debug-apk` artifact.
7. Extract the artifact and install the APK on the Android phone.

Android apps use Gradle/Android Gradle Plugin for builds. The GitHub workflow supplies a cloud Linux machine, Java and Android SDK, so no local computer is required for the build.
