# My Life OS — Complete Native Android Base
This is a single connected Android project base. It uses Kotlin + Jetpack Compose and Navigation Compose dependencies, with all core modules connected in one app shell.
Open in Android Studio, sync Gradle, then Build > Generate APK(s).
Owner: Muhamett Othmaan Omar
Support WhatsApp: +252614273478
