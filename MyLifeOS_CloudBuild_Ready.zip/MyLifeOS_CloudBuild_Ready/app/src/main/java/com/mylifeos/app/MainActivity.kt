package com.mylifeos.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class Task(val title:String,val time:String,val category:String,val done:Boolean=false)
data class Goal(val title:String,val progress:Int=0)
data class Expense(val title:String,val amount:Double,val income:Boolean)

class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{MyLifeOSApp()}}
}

@Composable fun MyLifeOSApp(){
 var page by remember{mutableStateOf("Dashboard")}
 var dark by remember{mutableStateOf(false)}
 var tasks by remember{mutableStateOf(listOf(
  Task("Morning routine","07:00","Personal"),
  Task("English study","10:00","Study"),
  Task("Prayer & Qur'an","18:30","Religion")
 ))}
 var goals by remember{mutableStateOf(listOf(Goal("Learn English",35),Goal("Become professional IT",15)))}
 var journal by remember{mutableStateOf("")}
 MaterialTheme(colorScheme=if(dark)darkColorScheme() else lightColorScheme()){
  Scaffold(topBar={TopAppBar(title={Text("MY LIFE OS")},actions={TextButton({dark=!dark}){Text(if(dark)"Light" else "Dark")}})},
   bottomBar={NavigationBar{listOf("Dashboard","Planner","Religion","Study","Finance","Goals","Journal","More").forEach{
    NavigationBarItem(page==it,{page=it},{Text(icon(it))},{Text(it)})
   }}}
  ){p->Box(Modifier.padding(p).fillMaxSize()){when(page){
   "Dashboard"->Dashboard(tasks,goals)
   "Planner"->Planner(tasks){tasks=it}
   "Religion"->Module("Religion","Prayer • Qur'an • Adhkar")
   "Study"->Module("Study","Subjects • Lessons • Study schedule")
   "Finance"->Finance()
   "Goals"->Goals(goals){goals=it}
   "Journal"->Journal(journal){journal=it}
   else->Module("More & Settings","Notifications • Backup & Restore • Support • App settings")
  }}}
 }
}

fun icon(s:String)=when(s){"Dashboard"->"⌂";"Planner"->"✓";"Religion"->"☾";"Study"->"📚";"Finance"->"₿";"Goals"->"★";"Journal"->"✎";else->"⚙"}

@Composable fun Dashboard(tasks:List<Task>,goals:List<Goal>){
 val done=tasks.count{it.done}
 LazyColumn(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item{Text("Good day 👋",style=MaterialTheme.typography.headlineMedium);Text("Your life, organized in one place.") }
  item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text("Today's progress");Text("$done / ${tasks.size} tasks completed")}}}
  item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text("Goals");goals.forEach{Text("${it.title} — ${it.progress}%")}}}}
  item{Text("Quick overview",style=MaterialTheme.typography.titleLarge)}
  item{ModuleCard("Religion","Prayer • Qur'an • Adhkar")}
  item{ModuleCard("Study","Today's learning plan")}
  item{ModuleCard("Finance","Income • Expenses • Balance")}
 }
}
@Composable fun ModuleCard(a:String,b:String){Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text(a,style=MaterialTheme.typography.titleLarge);Text(b)}}}

@Composable fun Planner(tasks:List<Task>,update:(List<Task>)->Unit){
 var title by remember{mutableStateOf("")}; var time by remember{mutableStateOf("")}
 Column(Modifier.padding(18.dp)){Text("Daily Planner",style=MaterialTheme.typography.headlineSmall)
  Row{OutlinedTextField(title,{title=it},Modifier.weight(1f),label={Text("Task")});Spacer(Modifier.width(8.dp));OutlinedTextField(time,{time=it},Modifier.width(100.dp),label={Text("Time")})}
  Button({if(title.isNotBlank()){update(tasks+Task(title,time,"Personal"));title="";time=""}},Modifier.padding(vertical=8.dp)){Text("Add Task")}
  LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(tasks){t->Card(Modifier.fillMaxWidth()){Row(Modifier.padding(12.dp)){Text(t.time,Modifier.width(60.dp));Text(t.title,Modifier.weight(1f));Checkbox(t.done,{v->update(tasks.map{if(it==t)it.copy(done=v)else it})})}}}}
 }
}
@Composable fun Goals(goals:List<Goal>,update:(List<Goal>)->Unit){
 var text by remember{mutableStateOf("")}; Column(Modifier.padding(18.dp)){Text("Goals & Habits",style=MaterialTheme.typography.headlineSmall)
  Row{OutlinedTextField(text,{text=it},Modifier.weight(1f),label={Text("New goal")});Button({if(text.isNotBlank()){update(goals+Goal(text));text=""}}){Text("+")}}
  goals.forEach{g->ModuleCard(g.title,"Progress: ${g.progress}%")}
 }
}
@Composable fun Finance(){
 Column(Modifier.padding(18.dp)){Text("Finance",style=MaterialTheme.typography.headlineSmall);ModuleCard("Income","Track money received");ModuleCard("Expenses","Track spending");ModuleCard("Balance","See your current balance")}
}
@Composable fun Journal(value:String,onChange:(String)->Unit){
 Column(Modifier.padding(18.dp)){Text("My Journal",style=MaterialTheme.typography.headlineSmall);OutlinedTextField(value,onChange,Modifier.fillMaxWidth().height(220.dp),label={Text("Today: learned, mistakes, gratitude, and Talk to Allah")})}
}
@Composable fun Module(title:String,desc:String){Column(Modifier.padding(18.dp)){Text(title,style=MaterialTheme.typography.headlineSmall);Spacer(Modifier.height(8.dp));ModuleCard(title,desc)}}
