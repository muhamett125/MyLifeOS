plugins {
 id("com.android.application"); id("org.jetbrains.kotlin.android"); id("org.jetbrains.kotlin.plugin.compose")
}
android { namespace="com.mylifeos.app"; compileSdk=36
 defaultConfig { applicationId="com.mylifeos.app"; minSdk=23; targetSdk=36; versionCode=1; versionName="1.0" }
 buildFeatures { compose=true }
}
dependencies {
 val bom=platform("androidx.compose:compose-bom:2026.09.00")
 implementation(bom); implementation("androidx.activity:activity-compose:1.13.0")
 implementation("androidx.compose.material3:material3"); implementation("androidx.compose.ui:ui")
 implementation("androidx.compose.ui:ui-tooling-preview"); debugImplementation("androidx.compose.ui:ui-tooling")
 implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.10.0")
 implementation("androidx.navigation:navigation-compose:2.10.2")
}
